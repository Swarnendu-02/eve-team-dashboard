<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>EVE Team ashboard</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width</td><td>initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <script src="js/jquery.min.js"></script>
    <script src="https://unpkg.com/chart.js@2.8.0/dist/Chart.bundle.js"></script>
    <script src="https://unpkg.com/chartjs-gauge@0.3.0/dist/chartjs-gauge.js"></script>
</head>

<body>
    <header class="container-fluid">
        <div>
            <button class="menu-btn"><i class="fas fa-th-large"></i></button>
            <img src="images/Logo eve 1.png" class="logo">
        </div>
        <a class="noti"><i class="fas fa-bell"></i><span>99</span></a>
    </header>
    <div class="container-fluid work-space">
        <div class="dash-top">
            <div class="dash-prf-box">
                <img src="images/no_img.jpg" class="prf-img">
                <div class="prf-detail">
                    <h4>Aakash Jaiswal</h4>
                    <h5>Founder & Chairman</h5>
                </div>
            </div>
            <div class="dash-top-rt">
                <div>
                    <a href="#">Team Dashboard<span><i class="fas fa-users"></i></span></a>
                </div>
                <div>
                    <a href="#">To-Do<span><i class="fas fa-clipboard-list"></i></span></a>
                </div>
            </div>
        </div>
        <div class="dash-heading">
            <h3>Dashboard</h3>
            <div class="dash-heading-rt">
                <div>
                    <label>Year</label>
                    <select>
                        <option>Select Year</option>
                    </select>
                </div>
                <div>
                    <label>Month</label>
                    <select>
                        <option>Select Month</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="attendance-table">
            <div class="table-heading">
                <h4>attendance</h4>
                <div class="table-heading-rt">
                    <div>
                        <span class="regularise"></span>
                        <h6>attendance regularise</h6>
                    </div>
                    <div>
                        <span class="late"></span>
                        <h6>Late Deduction</h6>
                    </div>
                </div>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>

                        </tr>
                        <tr>
                            <td colspan="2">1</td>
                            <td colspan="2">2</td>
                            <td colspan="2">3</td>
                            <td colspan="2">4</td>
                            <td colspan="2">5</td>
                            <td colspan="2">6</td>
                            <td colspan="2">7</td>
                            <td colspan="2">8</td>
                            <td colspan="2">9</td>
                            <td colspan="2">10</td>
                            <td colspan="2">11</td>
                            <td colspan="2">12</td>
                            <td colspan="2">13</td>
                            <td colspan="2">14</td>
                            <td colspan="2">15</td>
                            <td colspan="2">16</td>
                            <td colspan="2">17</td>
                            <td colspan="2">18</td>
                            <td colspan="2">19</td>
                            <td colspan="2">20</td>
                            <td colspan="2">21</td>
                            <td colspan="2">22</td>
                            <td colspan="2">23</td>
                            <td colspan="2">24</td>
                            <td colspan="2">25</td>
                            <td colspan="2">26</td>
                            <td colspan="2">27</td>
                            <td colspan="2">28</td>
                            <td colspan="2">29</td>
                            <td colspan="2">30</td>
                            <td colspan="2">31</td>
                        </tr>
                        <tr>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                            <td>In</td>
                            <td>Out</td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>
                            <td colspan="2"><input type="checkbox"></td>

                        </tr>
                        <tr>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="leave-report-table">
            <div class="table-heading">
                <h4>leave report</h4>
                <div class="table-heading-rt">
                    <div>
                        <span class="reject"></span>
                        <h6>Reject</h6>
                    </div>
                    <div>
                        <span class="approve"></span>
                        <h6>Approve</h6>
                    </div>
                    <div>
                        <span class="pending"></span>
                        <h6>Pending</h6>
                    </div>
                </div>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td class="reject" colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td class="approve" colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td class="pending" colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>

                        </tr>
                        <tr>
                            <td class="reject" colspan="2">1</td>
                            <td colspan="2">2</td>
                            <td colspan="2">3</td>
                            <td class="approve" colspan="2">4</td>
                            <td colspan="2">5</td>
                            <td colspan="2">6</td>
                            <td colspan="2">7</td>
                            <td class="pending" colspan="2">8</td>
                            <td colspan="2">9</td>
                            <td colspan="2">10</td>
                            <td colspan="2">11</td>
                            <td colspan="2">12</td>
                            <td colspan="2">13</td>
                            <td colspan="2">14</td>
                            <td colspan="2">15</td>
                            <td colspan="2">16</td>
                            <td colspan="2">17</td>
                            <td colspan="2">18</td>
                            <td colspan="2">19</td>
                            <td colspan="2">20</td>
                            <td colspan="2">21</td>
                            <td colspan="2">22</td>
                            <td colspan="2">23</td>
                            <td colspan="2">24</td>
                            <td colspan="2">25</td>
                            <td colspan="2">26</td>
                            <td colspan="2">27</td>
                            <td colspan="2">28</td>
                            <td colspan="2">29</td>
                            <td colspan="2">30</td>
                            <td colspan="2">31</td>
                        </tr>


                    </tbody>
                </table>
            </div>
        </div>
        <div class="ta-report-table">
            <div class="table-heading">
                <h4>TA report</h4>
                <div class="table-heading-rt">
                    <div>
                        <span class="reject"></span>
                        <h6>Reject</h6>
                    </div>
                    <div>
                        <span class="approve"></span>
                        <h6>Approve</h6>
                    </div>
                    <div>
                        <span class="pending"></span>
                        <h6>Pending</h6>
                    </div>
                </div>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>

                        </tr>
                        <tr>
                            <td colspan="2">1</td>
                            <td colspan="2">2</td>
                            <td colspan="2">3</td>
                            <td colspan="2">4</td>
                            <td colspan="2">5</td>
                            <td colspan="2">6</td>
                            <td colspan="2">7</td>
                            <td colspan="2">8</td>
                            <td colspan="2">9</td>
                            <td colspan="2">10</td>
                            <td colspan="2">11</td>
                            <td colspan="2">12</td>
                            <td colspan="2">13</td>
                            <td colspan="2">14</td>
                            <td colspan="2">15</td>
                            <td colspan="2">16</td>
                            <td colspan="2">17</td>
                            <td colspan="2">18</td>
                            <td colspan="2">19</td>
                            <td colspan="2">20</td>
                            <td colspan="2">21</td>
                            <td colspan="2">22</td>
                            <td colspan="2">23</td>
                            <td colspan="2">24</td>
                            <td colspan="2">25</td>
                            <td colspan="2">26</td>
                            <td colspan="2">27</td>
                            <td colspan="2">28</td>
                            <td colspan="2">29</td>
                            <td colspan="2">30</td>
                            <td colspan="2">31</td>
                        </tr>
                        <tr>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="reimbursement-report-table">
            <div class="table-heading">
                <h4>reimbursement report</h4>
                <div class="table-heading-rt">
                    <div>
                        <span class="reject"></span>
                        <h6>Reject</h6>
                    </div>
                    <div>
                        <span class="approve"></span>
                        <h6>Approve</h6>
                    </div>
                    <div>
                        <span class="pending"></span>
                        <h6>Pending</h6>
                    </div>
                </div>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>
                            <td colspan="2">Thu</td>
                            <td colspan="2">Fri</td>
                            <td colspan="2">Sat</td>
                            <td colspan="2">Sun</td>
                            <td colspan="2">Mon</td>
                            <td colspan="2">Tue</td>
                            <td colspan="2">Wed</td>

                        </tr>
                        <tr>
                            <td colspan="2">1</td>
                            <td colspan="2">2</td>
                            <td colspan="2">3</td>
                            <td colspan="2">4</td>
                            <td colspan="2">5</td>
                            <td colspan="2">6</td>
                            <td colspan="2">7</td>
                            <td colspan="2">8</td>
                            <td colspan="2">9</td>
                            <td colspan="2">10</td>
                            <td colspan="2">11</td>
                            <td colspan="2">12</td>
                            <td colspan="2">13</td>
                            <td colspan="2">14</td>
                            <td colspan="2">15</td>
                            <td colspan="2">16</td>
                            <td colspan="2">17</td>
                            <td colspan="2">18</td>
                            <td colspan="2">19</td>
                            <td colspan="2">20</td>
                            <td colspan="2">21</td>
                            <td colspan="2">22</td>
                            <td colspan="2">23</td>
                            <td colspan="2">24</td>
                            <td colspan="2">25</td>
                            <td colspan="2">26</td>
                            <td colspan="2">27</td>
                            <td colspan="2">28</td>
                            <td colspan="2">29</td>
                            <td colspan="2">30</td>
                            <td colspan="2">31</td>
                        </tr>
                        <tr>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">50.00</td>
                            <td colspan="2">100.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                            <td colspan="2">00.00</td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="advance-report-table">
            <div class="table-heading">
                <h4>advance report</h4>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Month</td>
                            <td>April</td>
                            <td>May</td>
                            <td>June</td>
                            <td>July</td>
                            <td>August</td>
                            <td>September</td>
                            <td>October</td>
                            <td>November</td>
                            <td>December</td>
                            <td>January</td>
                            <td>February</td>
                            <td>March</td>
                        </tr>
                        <tr>
                            <td>Opening Balance</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>New Loans</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Balance Repaid</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Closing Balance</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="salary-report-table">
            <div class="table-heading">
                <h4>salary report</h4>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Month</td>
                            <td>April</td>
                            <td>May</td>
                            <td>June</td>
                            <td>July</td>
                            <td>August</td>
                            <td>September</td>
                            <td>October</td>
                            <td>November</td>
                            <td>December</td>
                            <td>January</td>
                            <td>February</td>
                            <td>March</td>
                        </tr>
                        <tr>
                            <td>Actual Salary</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Earned Salary</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="incentive-report-table">
            <div class="table-heading">
                <h4>incentive report</h4>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Month</td>
                            <td>April</td>
                            <td>May</td>
                            <td>June</td>
                            <td>July</td>
                            <td>August</td>
                            <td>September</td>
                            <td>October</td>
                            <td>November</td>
                            <td>December</td>
                            <td>January</td>
                            <td>February</td>
                            <td>March</td>
                        </tr>
                        <tr>
                            <td>Incentive Earned</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="overtime-report-table">
            <div class="table-heading">
                <h4>overtime report</h4>
            </div>
            <div class="table-content">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Month</td>
                            <td>April</td>
                            <td>May</td>
                            <td>June</td>
                            <td>July</td>
                            <td>August</td>
                            <td>September</td>
                            <td>October</td>
                            <td>November</td>
                            <td>December</td>
                            <td>January</td>
                            <td>February</td>
                            <td>March</td>
                        </tr>
                        <tr>
                            <td>Hourse</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Rate</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Total Amount</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="g2">
            <div>
                <div class="holiday-table">
                    <div class="table-2-header">
                        <h4>Holiday List</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Occation</td>
                                    <td>Number of Days</td>
                                    <td>Form - To</td>
                                    <td>Day</td>
                                </tr>
                                <tr>
                                    <td>Holi</td>
                                    <td>1</td>
                                    <td>08.03.2023</td>
                                    <td>Wednesday</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="notice-table">
                    <div class="table-2-header">
                        <h4>Notice</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Date</td>
                                    <td>Subject</td>
                                </tr>
                                <tr>
                                    <td>08.03.2023</td>
                                    <td class="flag">Lorem Ipsum<span><img src="images/red-flag.png"></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="amount-credited-table">
                    <div class="table-2-header">
                        <h4>Amount Credited</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Salary</td>
                                    <td>200000.00</td>
                                </tr>
                                <tr>
                                    <td>Traveling Allowance</td>
                                    <td>6000.00</td>
                                </tr>
                                <tr>
                                    <td>Reimbursement</td>
                                    <td>3000.00</td>
                                </tr>
                                <tr>
                                    <td>Advance</td>
                                    <td>10000.00</td>
                                </tr>
                                <tr>
                                    <td>Loan</td>
                                    <td>5000.00</td>
                                </tr>
                                <tr>
                                    <td>Total</td>
                                    <td>440000.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="leave-balance-table">
                    <div class="table-2-header">
                        <h4>Leave Balance</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Casual Leave</td>
                                    <td>Sick Leave</td>
                                    <td>Paid Leave</td>
                                    <td>Total</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>5</td>
                                    <td>5</td>
                                    <td>20</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div>
                <div class="leave-table">
                    <div class="table-2-header">
                        <h4>Leave List</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Reason</td>
                                    <td>Number of Days</td>
                                    <td>Form - To</td>
                                    <td>Day</td>
                                </tr>
                                <tr>
                                    <td>Fever</td>
                                    <td>2</td>
                                    <td>09.03.2023 - 10.03.2023</td>
                                    <td>Thursday</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="assets-table">
                    <div class="table-2-header">
                        <h4>Assets in Hand</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Date</td>
                                    <td>Detail</td>

                                </tr>
                                <tr>
                                    <td>09.03.2023</td>
                                    <td>Laptop</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="requested-table">
                    <div class="table-2-header">
                        <h4>Requested Item</h4>
                    </div>
                    <div class="table-content">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Date</td>
                                    <td>Item</td>
                                    <td>Quantity</td>
                                    <td>Status</td>
                                </tr>
                                <tr>
                                    <td>09.03.2023</td>
                                    <td>Laptop</td>
                                    <td>1</td>
                                    <td>Pending<span class="status pending"></span></td>
                                </tr>
                                <tr>
                                    <td>09.03.2023</td>
                                    <td>Laptop</td>
                                    <td>1</td>
                                    <td>Approve<span class="status approve"></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="g2">
                    <div class="birthday-table">
                        <div class="table-2-header">
                            <h4>Upcoming Birthdays</h4>
                        </div>
                        <div class="table-content">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td>Profile</td>
                                        <td>Name</td>
                                        <td>Date</td>
                                    </tr>
                                    <tr>
                                        <td><img src="images/no_img.jpg" class="brth-img"></td>
                                        <td>Aakash Jaiswal</td>
                                        <td>09.03.2023</td>
                                    </tr>
                                    <tr>
                                        <td><img src="images/no_img.jpg" class="brth-img"></td>
                                        <td>Aakash Jaiswal</td>
                                        <td>09.03.2023</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="anniversaries-table">
                        <div class="table-2-header">
                            <h4>Upcoming Anniversaries</h4>
                        </div>
                        <div class="table-content">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td>Profile</td>
                                        <td>Name</td>
                                        <td>Date</td>
                                    </tr>
                                    <tr>
                                        <td><img src="images/no_img.jpg" class="brth-img"></td>
                                        <td>Aakash Jaiswal</td>
                                        <td>09.03.2023</td>
                                    </tr>
                                    <tr>
                                        <td><img src="images/no_img.jpg" class="brth-img"></td>
                                        <td>Aakash Jaiswal</td>
                                        <td>09.03.2023</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>